# Java, NetBeans, SceneBuilder - Data Entry App - Part 01 - Add Student

Here is the Java, NetBeans, SceneBuilder source code for my video tutorial:
* YouTube: https://youtu.be/P4D73ZEaja0
* LBRY / Odysee:

Please see the description below the video for further details, software used, download links, etc.

**Moose**
<br>Moose's Software Valley - Established July, 1996.
<br>https://rebrand.ly/MoosesSoftware
